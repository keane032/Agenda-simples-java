15_agenda_simples
========

Repositório público: https://github.com/qxcodepoo/

## Objetivo

1. Implementar a classe Cadastro e a classe Contato a partir das interfaces.
2. Implementar alguns algoritmos simples sobre listas como filtragem.
3. Trabalhar na verificação das entradas de dados. 

## Requisitos

Classes: List, ArrayList, Encapsulamento, Interfaces, String.

## Entrada

Interface ICadastro com o serviço. Interface auxiliar IContato.
Classe de testes.